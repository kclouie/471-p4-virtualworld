Kalea Louie
CPE 471
Project 4

2 Models:
---------
- 20 Trees - downloaded obj from internet
- 20 Penguins - built hierarchically using downloaded spheres and cubes

- 40 Models total, randomly generated

Lighting:
---------
Directional

Collision Detection:
--------------------
None

